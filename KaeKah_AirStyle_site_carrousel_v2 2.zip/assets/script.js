// Vanilla JS carousel
(function(){
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  const track = document.querySelector('.track');
  const prevBtn = document.querySelector('.prev');
  const nextBtn = document.querySelector('.next');
  const dotsWrap = document.querySelector('.dots');
  const images = (typeof IMAGES !== 'undefined') ? IMAGES : [];

  // Build slides
  images.forEach(src => {
    const slide = document.createElement('div');
    slide.className = 'slide';
    const img = document.createElement('img');
    img.src = src;
    img.alt = 'Réalisation — tresses (visage masqué)';
    slide.appendChild(img);
    track.appendChild(slide);
  });

  const slides = Array.from(document.querySelectorAll('.slide'));
  let index = 0;

  // Dots
  images.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.className = 'dot' + (i===0 ? ' active' : '');
    dot.setAttribute('aria-label', 'Aller à la diapositive ' + (i+1));
    dot.addEventListener('click', () => goTo(i));
    dotsWrap.appendChild(dot);
  });
  const dots = Array.from(document.querySelectorAll('.dot'));

  function update(){
    track.style.transform = `translateX(-${index*100}%)`;
    dots.forEach((d,i)=>d.classList.toggle('active', i===index));
  }
  function goTo(i){
    index = Math.max(0, Math.min(i, slides.length-1));
    update();
  }
  function next(){ goTo(index+1); }
  function prev(){ goTo(index-1); }

  nextBtn.addEventListener('click', next);
  prevBtn.addEventListener('click', prev);
  document.addEventListener('keydown', (e)=>{
    if (e.key === 'ArrowRight') next();
    if (e.key === 'ArrowLeft') prev();
  });

  // Auto-play (optional)
  let timer = setInterval(next, 5000);
  [track, prevBtn, nextBtn, dotsWrap].forEach(el=>{
    el.addEventListener('mouseenter', ()=> clearInterval(timer));
    el.addEventListener('mouseleave', ()=> timer = setInterval(next, 5000));
  });

  update();
})();